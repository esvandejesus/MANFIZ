"""Optional Matplotlib figures generated from actual arrays, never synthetic art."""
from pathlib import Path
import numpy as np


def plot_training(report,path):
    import matplotlib.pyplot as plt
    values=np.asarray(report['objective_history'])[:,0]
    fig,ax=plt.subplots(figsize=(7.2,3.6),layout='constrained')
    ax.plot(np.arange(len(values)),values,color='#7d9ab8',lw=.6,alpha=.65,label='Evaluated objective')
    ax.plot(np.minimum.accumulate(values),color='#123c61',lw=1.5,label='Best so far')
    ax.set(xlabel='Objective evaluation (includes initial/final audits)',ylabel='Joint normalized objective',
           title='Shared-premise training from scratch',yscale='log')
    ax.legend(frameon=False); ax.grid(alpha=.2)
    path=Path(path); fig.savefig(path,dpi=180); fig.savefig(path.with_suffix('.svg')); plt.close(fig)


def plot_intervals(indices,y,prediction,path,*,system=None):
    import matplotlib.pyplot as plt
    y=np.asarray(y); indices=np.asarray(indices)
    n=y.shape[1]
    fig,axes=plt.subplots(n,2,figsize=(11,2.6*n),squeeze=False,layout='constrained')
    start=max(0,len(y)//2-60); end=min(len(y),start+120)
    for o in range(n):
        for j,sl in enumerate((slice(None),slice(start,end))):
            ax=axes[o,j]; k=indices[sl]
            ax.fill_between(k,prediction.lower[sl,o],prediction.upper[sl,o],color='#cfe0ee',label='Noise-inclusive interval')
            ax.plot(k,prediction.center[sl,o],color='#174c72',lw=.8,label='MANFIZ center')
            ax.plot(k,y[sl,o],color='#ad491f',lw=.65,label='Measured output')
            ax.set(xlabel='Sample k (zero-based)',ylabel=f'y{o+1} (physical units)',
                   title=f'Output {o+1}' + (' — detail' if j else ' — full run'))
            ax.grid(alpha=.17)
    handles,labels=axes[0,0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='outside lower center',ncol=3,frameon=False)
    fig.suptitle(f'System {system}: independent held-out run' if system else 'Held-out intervals')
    path=Path(path); fig.savefig(path,dpi=180); fig.savefig(path.with_suffix('.svg')); plt.close(fig)
